package com.redis.sentinel.client;

public enum type_t {
	STRING,
	ARRAY,
	INTEGER,
	NIL,
	STATUS,
	ERROR
}
