#ifndef KVPROXY_VER_H
#define KVPROXY_VER_H

#define KVPROXY_VERSION 0.1
#define KVPROXY_BUILT "2015-01-11"

#endif 
