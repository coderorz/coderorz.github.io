﻿#pragma once

namespace ven {

  template <class T>
  struct Next {
    T* next_ = nullptr;
  };

}