﻿#include "stdafx.h"

int main(int argc, char *argv[])
{
  printf("empty project\n");
  return 0;
}

